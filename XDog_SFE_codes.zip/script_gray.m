close all;
clear all;
clear
  
% [imagename1 imagepath1]=uigetfile('\*.jpg;*.bmp;*.png;*.tif;*.tiff;*.pgm;*.gif','Please choose the first input image');
% A=imread(strcat(imagepath1,imagename1)); 
% [imagename2 imagepath2]=uigetfile('\*.jpg;*.bmp;*.png;*.tif;*.tiff;*.pgm;*.gif','Please choose the first input image');
% B=imread(strcat(imagepath2,imagename2)); 
A=imread('01c01_CT.png');
B=imread('01c01_MR.png');

B = im2double(B);   
A= im2double(A); 

if size(A,3)>1
    A=rgb2gray(A);           
end
if size(B,3)>1
    B=rgb2gray(B);            
end
[row,column]=size(A);
tic
%% Initail fusion
map1=abs(A>B);
F1=A.*map1+~map1.*B;
G=fspecial('average',3);
F1_L=imfilter(F1,G);
%% Detail layers
A_L=imfilter(A,G);
B_L=imfilter(B,G);
A_H=A-A_L;
B_H=B-B_L;
%% Detail extraction using XDoG
Gamma = 0.98;
Phi = 200;
Epsilon = -0.1;
k =1.6;
Sigma= 0.8;
%%
BOA=Xdog2(A_H,Gamma,Phi,Epsilon,k,Sigma);
BOB=Xdog2(B_H,Gamma,Phi,Epsilon,k,Sigma);

EB=BOA>BOB;
EA=BOB>BOA;

%% Decision map of detail layers
w=9;
GE_A=SF(A_H,w).*local_energy(A_H,w);
GE_B=SF(B_H,w).*local_energy(B_H,w);
map1=(abs(GE_A)>abs(GE_B));
map2=(abs(GE_B)>abs(GE_A));

for i=1:row
    for  j=1:column 
      if BOB(i,j)>BOA(i,j)
           map1(i,j)=EA(i,j);
    end
    end 
end
 
 for i=1:row
 for  j=1:column 
      if BOA(i,j)>BOB(i,j)
           map2(i,j)=EB(i,j);
    end
 end 
 end
 
%% FGF
r=4;
eps = 0.02^2;
S=4;

MA_H_guide=fastguidedfilter(A, map1, r, eps,S);
MB_H_guide=fastguidedfilter(B, map2, r, eps,S);

H_F1= A_H.*MA_H_guide+B_H.*MB_H_guide;   

F=F1_L+H_F1;

toc
figure,imshow(F); 

