# medical-image-fusion_code

This package contains the matlab code which is associated with the following paper:

Yuchan Jie, Haishu Tan, Xiaoqi Cheng, Fuqiang Zhou, Mingyi Wang, Yanxiong Wu, Xiaosong Li. Multimodal medical image fusion based on extended difference-of-Gaussians and fast guided filtering.
Usage of this code is free for research purposes only. 

Please refer to the above publication if you use this code.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

The demo files are script_gray.m and script_color.m. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Do not hesitate to let me know if you have any queries when using this code.


Li Xiaosong,et al.   
                                                         
E-mail: lixiaosong@buaa.edu.cn

Last update: 12-23-2020